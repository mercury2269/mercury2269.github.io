﻿using System;
using System.Web;
using CustomAuthenticationSample.Application;

namespace CustomAuthenticationSample.Account
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            RegisterHyperLink.NavigateUrl = "Register.aspx?ReturnUrl=" + HttpUtility.UrlEncode(Request.QueryString["ReturnUrl"]);
        }

        public void OnLoginClick(object sender, EventArgs e)
        {
            if(true) // this is where you would check if user is valid
            {
                CustomAuthentication.SetAuthCookies("mercury2269", "Sergey Maskalik");
                Response.Redirect("/");
            }
        }
    }
}
