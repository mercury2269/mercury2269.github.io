using System;
using System.Web;
using System.Web.Security;

namespace CustomAuthenticationSample.Application
{
    public class CustomAuthentication
    {
        public static void SetAuthCookies(string userName, string fullName)
        {
            FormsAuthenticationTicket identityTicket = new FormsAuthenticationTicket(1, userName, DateTime.Now, DateTime.Now.AddDays(60), true, fullName);
            string encryptedIdentityTicket = FormsAuthentication.Encrypt(identityTicket);
            var identityCookie = new HttpCookie("ASPXIDENT", encryptedIdentityTicket);
            identityCookie.Expires = DateTime.Now.AddDays(60);
            HttpContext.Current.Response.Cookies.Add(identityCookie);

            FormsAuthentication.SetAuthCookie(userName,false);
        }
    }
}