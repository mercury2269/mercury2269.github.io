﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CustomAuthenticationSample.Application;

namespace CustomAuthenticationSample
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(IdentityHelper.CurrentUser.HasIdentity)
            {
                lblIdentityInfo.Text = "Whoo hoo User has identity, full name is: " + IdentityHelper.CurrentUser.FullName;
            }

            if(IdentityHelper.CurrentUser.IsAuthenticated)
            {
                lblIdentityInfo.Text += "<br />User has secure authentication session";
            }
        }
    }
}
