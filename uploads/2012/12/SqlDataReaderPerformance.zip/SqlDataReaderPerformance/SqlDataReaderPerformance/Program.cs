﻿using System;
using System.Diagnostics;
using System.Data.SqlClient;

namespace SqlDataReaderPerformance
{
    class Program
    {
        static void Main(string[] args)
        {
            int loops = 1000;

            int contactID;
            string firstName;
            string middleName = null;
            string lastName;


            string sqlConnectString = @"Data Source=(local)\SQLEXPRESS2008;" +
                "Integrated security=SSPI;Initial Catalog=AdventureWorks;";

            string sqlSelect = "SELECT BusinessEntityID, FirstName, MiddleName, LastName " +
                "FROM Person.Person";

            Console.WriteLine("---DataReader column value access timing test, " +
                "{0} iterations---\n", loops);

            using (SqlConnection connection = new SqlConnection(sqlConnectString))
            {
                // Create the command and open the connection
                SqlCommand command = new SqlCommand(sqlSelect, connection);
                connection.Open();

                var watch = Stopwatch.StartNew();

                for (int i = 0; i < loops; i++)
                {
                    using (SqlDataReader dr = command.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            contactID = dr.GetInt32(0);
                            firstName = dr.GetString(1);
                            middleName = dr.IsDBNull(2) ? null : dr.GetString(2);
                            lastName = dr.GetString(3);
                        }

                    }
                }
                watch.Stop();
                Console.WriteLine("Typed accessor: Time = {0}", ElapsedTime(watch));

                watch.Restart();
                for (int i = 0; i < loops; i++)
                {
                    // Create the DataReader and retrieve all fields for each
                    // record using a column ordinal
                    using (SqlDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            contactID = Convert.ToInt32(dr[0]);
                            firstName = Convert.ToString(dr[1]);
                            middleName = Convert.ToString(dr[2]);
                            lastName = Convert.ToString(dr[3]);
                        }


                    }
                }
                watch.Stop();
                Console.WriteLine("Casting with reader[n]: Time = {0}", ElapsedTime(watch));

                watch.Restart();
                for (int i = 0; i < loops; i++)
                {
                    using (SqlDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            contactID = Convert.ToInt32(dr["BusinessEntityID"]);
                            firstName = Convert.ToString(dr["FirstName"]);
                            middleName = Convert.ToString(dr["MiddleName"]);
                            lastName = Convert.ToString(dr["LastName"]);
                        }


                    }
                }
                watch.Stop();
                Console.WriteLine("Casting with reader[\"name\"]: Time = {0}", ElapsedTime(watch));

                watch.Restart();
                for (int i = 0; i < loops; i++)
                {
                    int contactIdOrdinal, firstNameOrdinal, lastNameOrdinal, middleNameOrdinal;

                    using (SqlDataReader dr = command.ExecuteReader())
                    {
                        contactIdOrdinal = dr.GetOrdinal("BusinessEntityID");
                        firstNameOrdinal = dr.GetOrdinal("FirstName");
                        middleNameOrdinal = dr.GetOrdinal("MiddleName");
                        lastNameOrdinal = dr.GetOrdinal("LastName");                      
                        while (dr.Read())
                        {
                            contactID = dr.GetInt32(contactIdOrdinal);
                            firstName = dr.GetString(firstNameOrdinal);
                            middleName = dr.IsDBNull(middleNameOrdinal) ? null : dr.GetString(middleNameOrdinal);
                            lastName = dr.GetString(lastNameOrdinal);
                        }
                    }
                }
                watch.Stop();
                Console.WriteLine("Typed with ordinals dr.GetInt32(dr.GetOrdinal(\"name\")) : Time = {0}", ElapsedTime(watch));

            }
            Console.WriteLine("\nPress any key to continue.");

            Console.ReadKey();
        }

        public static string ElapsedTime(Stopwatch watch)
        {
            TimeSpan ts = watch.Elapsed;

            // Format and display the TimeSpan value. 
            string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                ts.Hours, ts.Minutes, ts.Seconds,
                ts.Milliseconds / 10);
            return elapsedTime;
        }
    }
}

